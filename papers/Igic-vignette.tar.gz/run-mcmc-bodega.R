################################
###  run-mcmc-bodega.R                     ###
### MCMC analysis on ML tree          ###
### (Goldberg et al. 2010)                   ###
################################

### DATA PREPARATION ###

library(diversitree)

# Import Tree
# Maximum likelihood tree, smoothed with penalized likelihood.
# Be sure to place the NicSolPLML.tre file into the right directory or paste the directory path immediately preceeding the file name.

tree <- read.tree(file="NicSolPLML.tre")
i <- which(tree$node.label == "")
tree$node.label[i] = paste("node", i, sep="")

# Import Tip States (see README.txt)
# 0 = SI, 1 = SC
# states 2:5 are more difficult to encode, but 2,3,& 5 are all mostly SI, and 4 is mostly SC. 

dat <- read.csv("NicSolstatus.csv")
states <- dat$Status
names(states) <- dat$Species
states[states %in% c(2, 3, 5)] <- 0
states[states == 4] <- 1
table(states)

# Adjustment for Incomplete Sampling
# The proportion of species sampled for each state (SI,SC); SI species were relatively more likely to be found on the tree, although both states were sampled around 15% of the total estimated to occur in the family (from the character state data that includes species without phylogenetic data). 

sampling.f <- c(0.1628325, 0.1500414)

### ANALYSES ###

# Initial Parameter Values
# lambda.SI = speciation rate for SI
# lambda.SC = speciation rate for SC
# mu.SI = extinction rate for SI
# mu.SC = extinction rate for SC
# q.IC = transition rate from SI to SC 
# q.CI, the reversal rate, is not estimated here; extra credit exercise opportunities abound.

par.start <- c(3.1, 5.2, 2.6, 5.4, 0.5)
names(par.start) <- c("lambda.SI", "lambda.SC", "mu.SI", "mu.SC", "q.IC")

# The Likelihood Function 

lnL.full <- make.bisse(tree, states, sampling.f=sampling.f)
lnL.constr <- constrain(lnL.full, q10 ~ 0)

# Find ML
# It is much better to avoid single point estimation, 
# when the process has so much uncertainty, 
# but here is the ML for two particularly interesting models,
# (full 6-parameter, and constrained, no-reversals 5-parameter)
# NOTE: we fixed some nodes to SI in original analyses (see paper)

find.mle(lnL.full,p) # lnL = -941.9432
find.mle(lnL.constr,p) # lnL = -949.2878

# Run the MCMC
# This takes a long time, so it's generally safer to run it in batches, writing out the results along the way.
# Below, we write results in user-defined chunks = ntotal / nstep, to the same mcmc-results.dat file.

outfile <- "mcmc-results.dat"
cat("i", names(par.start), "p\n", file=outfile)

ntotal <- 100000
nstep  <- 1000
nbatch <- ntotal/nstep

for (i in seq(nbatch))
{
    ans <- mcmc(lnL.constr, par.start, nsteps=nstep, 
                w=c(1.75, 1.75, 1.75, 1.75, 0.75),
                upper=c(10, 10, 10, 10, 3), lower=0,
                prior=make.prior.exponential(0.3))
    write.table(ans, file=outfile, quote=F, row.names=F, append=F, col.names=T)
    par.start <- as.numeric(ans[nstep,2:6])
}