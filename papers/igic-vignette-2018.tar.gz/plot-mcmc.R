################################
###  plot-mcmc-bodega.R                     ###
### view MCMC results                         ###
### (Goldberg et al. 2010)                    ###
################################

library(diversitree)   # for profiles.plot()

# Reads the results from the saved file
# In case of errors, check file location, or use this code to browse for it: 
# dat <- read.table(file=file.choose(), header=T) 

dat <- read.table("mcmc-results-orig-10k.dat", header=T) 

cex <- 1.4
nbreaks <- 200

pdf("mcmc-hists.pdf", width=10, height=10)
par(mfrow=c(2,2))

### all params ###

legend.text1 <- c(expression(q[IC]), "", expression(lambda[I]), 
                  expression(lambda[C]), expression(mu[I]), expression(mu[C]))
col1 <- c("black", "white", "#ff0000", "#cccc00", "#0000ff", "#00aaff")
col1fill <- diversitree:::add.alpha(col1, alpha=0.55)
profiles.plot(dat[c(6,2,3,4,5)], col.line=col1[-2], col.fill=col1fill[-2], 
              xlab="", ylab="", n.br=nbreaks, cex.axis=cex)
title(main="parameter estimates", xlab="rate", ylab="density", cex.lab=cex, 
      cex.main=cex, font.main=3)
legend("topright", legend.text1, text.col=col1, col=col1, pch=22, 
        pt.bg=col1fill, bty="n", cex=cex, ncol=3)

### net diversification ###

dat.r <- data.frame(rSI=dat$lambda.SI - dat$mu.SI, 
                    rSC=dat$lambda.SC - dat$mu.SC)
legend.text2 <- c(expression(r[I] == lambda[I] - mu[I]), 
                  expression(r[C] == lambda[C] - mu[C]))
col2 <- c("#7d26cd", "#00cdcd")
col2fill <- col2
profiles.plot(dat.r, col.line=col2, col.fill=col2fill, xlab="", ylab="", 
              n.br=nbreaks, cex.axis=cex)
legend("topright", legend.text2, text.col=col2, col=col2, pch=22, 
        pt.bg=col2fill, bty="n", cex=cex)
title(main="net diversification", xlab="rate", ylab="density", cex.lab=cex,
      cex.main=cex, font.main=3)

### fate of SI ###

dat.fate <- data.frame(fate=dat.r$rSI - dat.r$rSC - dat$q.IC)
legend.text3 <- expression(r[I] - r[C] - q[IC])
col3 <- "black"
col3fill <- diversitree:::add.alpha(col3, alpha=0.3)
profiles.plot(dat.fate, col.line=col3, col.fill=col3fill, xlab="", ylab="", 
              n.br=nbreaks, cex.axis=cex, xlim=c(0,max(dat.fate)))
title(main="fate of SI", xlab="rate", ylab="density", cex.lab=cex, cex.main=cex,
      font.main=3)
legend("topright", legend.text3, text.col=col3, col=col3, pch=22, 
        pt.bg=col3fill, bty="n", cex=cex)

### equilibrium frequency of SI ###

dat.eqfreq <- data.frame(eqfreq = 1 - dat$q.IC / (dat.r$rSI - dat.r$rSC))
legend.text4 <- expression(p[SI])
profiles.plot(dat.eqfreq, col.line=col3, col.fill=col3fill, xlab="", ylab="",
              n.br=nbreaks, cex.axis=cex, xlim=c(0,max(dat.eqfreq)))
title(main="equilibrium frequency of SI", xlab="frequency", ylab="density",
      cex.lab=cex, cex.main=cex, font.main=3)
legend("topright", legend.text4, text.col=col3, col=col3, pch=22, 
        pt.bg=col3fill, bty="n", cex=cex)

dev.off()
