################################
###  run-mcmc-bodega.R                     ###
### MCMC analysis on ML tree          ###
### (Goldberg et al. 2010)                   ###
################################

### DATA PREPARATION ###

library(diversitree)

# Import Tree
# Maximum likelihood tree, smoothed with penalized likelihood.
# Be sure to place the NicSolPLML.tre file into the right directory or paste the directory path immediately preceeding the file name.

tree <- read.tree(file="NicSolPLML.tre")
i <- which(tree$node.label == "")
tree$node.label[i] = paste("node", i, sep="")

# Import Tip States (see README.txt)
dat <- read.csv("NicSolstatus.csv")
table(dat)

# Now let's recode a variety of breeding systems into a binary designation
# 0 = SI, 1 = SC
# states 2,3,& 5 are all mostly, or close to SI, and 4 is mostly SC. 
states <- dat$Status
names(states) <- dat$Species
states[states %in% c(2, 3, 5)] <- 0
states[states == 4] <- 1

# Let's see the current distribution of character states
table(states)

# Adjustment for Incomplete Sampling
# The proportion of species sampled for each state (SI,SC); SI species were relatively more likely to be found on the tree, although both states were sampled around 15% of the total estimated to occur in the family (from the character state data that includes species without phylogenetic data). 

sampling.f <- c(0.1628325, 0.1500414)

### ANALYSES ###

# Initial Parameter Values
#1. lambda.SI = speciation rate for SI
#2.  lambda.SC = speciation rate for SC
#3.  mu.SI = extinction rate for SI
#4.  mu.SC = extinction rate for SC
#5.  q.IC = transition rate from SI to SC 
#6.  q.CI = the reversal rate, from SC to SI

# perform the full six-parameter analysis

par.start.6 <- c(3.1, 5.2, 2.6, 5.4, 0.5, 0.0)
names(par.start) <- c("lambda.SI", "lambda.SC", "mu.SI", "mu.SC", "q.IC", "q.CI")

# The Likelihood Function 
lnL.full <- make.bisse(tree, states, sampling.f=sampling.f)

# Find ML: takes 10 seconds on my MacBook Air 2013
# It is much better to avoid single point estimation, 
# when the process has so much uncertainty, 
# try messing around with starting parameters
# Does the answer change if you set them all to 1.0?

find.mle(lnL.full,par.start) 
# answer: lnL = -941.9375

# perform the constrained five-parameter analysis
# we are now knocking out reversals

par.start.5 <- c(3.1, 5.2, 2.6, 5.4, 0.5)
lnL.constr <- constrain(lnL.full, q10 ~ 0)
find.mle(lnL.constr, par.start.5) 
# answer: lnL = -949.2868
